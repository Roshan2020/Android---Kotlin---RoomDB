package com.file.roomdb

class AppConstants {
    companion object{
        const val UserTable = "User"
        const val Database = "RoomDB"
        const val User = "UserData"
        const val UserID = "UserID"
    }
}