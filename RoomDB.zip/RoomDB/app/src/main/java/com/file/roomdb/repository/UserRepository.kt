package com.file.roomdb.repository

import androidx.annotation.WorkerThread
import com.file.roomdb.database.dao.UserDao
import com.file.roomdb.database.entity.User

class UserRepository(var userDao: UserDao) {
    @WorkerThread
    suspend fun getAllData(): MutableList<User>{
        return userDao.getAllData()
    }

    @WorkerThread
    suspend fun insertData(user: User){
        userDao.insertData(user)
    }

    @WorkerThread
    suspend fun deleteData(id: Int){
        userDao.deleteData(id)
    }

    @WorkerThread
    suspend fun getData(id: Int): User{
        return userDao.getData(id)
    }

    @WorkerThread
    suspend fun updateData(givenName: String, familyName: String, age: String, id: Int){
        userDao.updateData(givenName, familyName, age, id)
    }
}