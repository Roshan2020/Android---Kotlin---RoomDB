package com.file.roomdb.listener

import com.file.roomdb.database.entity.User

interface UserListener {
    fun onInsert()
    fun onGetData(user: MutableList<User>)
    fun onUpdate(position: Int)
    fun onDelete(id: Int)
    fun onGetUser(user: User)
    fun onUpdate()
}