package com.file.roomdb.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.file.roomdb.AppConstants
import com.file.roomdb.R
import com.file.roomdb.adapter.UserAdapter
import com.file.roomdb.database.DatabaseBuilder
import com.file.roomdb.database.RoomDBDatabase
import com.file.roomdb.database.entity.User
import com.file.roomdb.databinding.ActivityUserListBinding
import com.file.roomdb.listener.UserListener
import com.file.roomdb.repository.UserRepository
import com.file.roomdb.viewmodel.UserViewModel

class UserListActivity : AppCompatActivity(), UserListener {
    var binding: ActivityUserListBinding? = null
    var userAdapter: UserAdapter? = null
    var userViewModel: UserViewModel? = null
    var database: RoomDBDatabase? =  null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserListBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        database = DatabaseBuilder.getInstance(this)
        userViewModel = UserViewModel(this, UserRepository(database!!.UserDao()))
        userAdapter = UserAdapter(this, this)
        binding!!.rvListUser.adapter = userAdapter

        binding!!.btnAddUser.setOnClickListener{
            var intent = Intent(this@UserListActivity, AddUserActivity::class.java)
            startActivity(intent)
        }


    }

    fun getUsers(){
        userViewModel!!.getAllData()
    }

    override fun onResume() {
        super.onResume()
        getUsers()
    }

    override fun onInsert() {

    }

    override fun onGetData(user: MutableList<User>) {
        userAdapter!!.update(user)
    }

    override fun onUpdate(id: Int) {
        var intent = Intent(this@UserListActivity, UpdateUserActivity::class.java)
        intent.putExtra(AppConstants.UserID, id)
        startActivity(intent)
    }

    override fun onUpdate() {

    }

    override fun onDelete(id: Int) {
        userViewModel!!.deleteData(id)
    }

    override fun onGetUser(user: User) {

    }
}