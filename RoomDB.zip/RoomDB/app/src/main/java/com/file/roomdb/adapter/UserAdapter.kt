package com.file.roomdb.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.file.roomdb.database.entity.User
import com.file.roomdb.databinding.ItemUserBinding
import com.file.roomdb.listener.UserListener

class UserAdapter(var context: Context, var listener: UserListener) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {
    var binding: ItemUserBinding? = null
    var user:  MutableList<User> = mutableListOf()

    inner class UserViewHolder(itemUserBinding: ItemUserBinding) : RecyclerView.ViewHolder(itemUserBinding.root){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        binding = ItemUserBinding.inflate(inflater, parent, false)
        return UserViewHolder(binding!!)
    }

    override fun getItemCount(): Int {
        return user.size
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        binding!!.tvGivenName.text = user[position].givenName
        binding!!.tvFamilyName.text = user[position].familyName
        binding!!.tvAge.text = user[position].age

        binding!!.btnDelete.setOnClickListener{
            listener.onDelete(user[position].id!!)
        }

        binding!!.btnUpdate.setOnClickListener{
            listener.onUpdate(user[position].id!!)
        }
    }

    fun update(list: MutableList<User>){
        user = list
        notifyDataSetChanged()
    }
}