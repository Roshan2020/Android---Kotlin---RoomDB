package com.file.roomdb.viewmodel

import android.content.DialogInterface.OnClickListener
import android.util.Log
import androidx.lifecycle.ViewModel
import com.file.roomdb.listener.UserListener
import com.file.roomdb.repository.UserRepository
import androidx.lifecycle.viewModelScope
import com.file.roomdb.database.entity.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class UserViewModel(var listener: UserListener, var userRepository: UserRepository): ViewModel() {

    fun getAllData(){
        GlobalScope.launch(Dispatchers.IO) {
            try { 
                var users =  userRepository.getAllData()
                listener.onGetData(users)
            } catch (e: Exception){
                Log.e("Error", e.message!!)
            }
        }
    }

    fun insertData(user: User){
        viewModelScope.launch {
            try {
                userRepository.insertData(user)
                listener.onInsert()
            } catch (e: Exception){
                Log.e("Error", e.message!!)
            }
        }
    }

    fun deleteData(id: Int){
        viewModelScope.launch {
            try {
                userRepository.deleteData(id)
                getAllData()
            } catch (e: Exception){
                Log.e("Error", e.message!!)
            }
        }
    }

    fun getData(id: Int){
        viewModelScope.launch {
            try {
                var user = userRepository.getData(id)
                listener.onGetUser(user)
            } catch (e: Exception) {
                Log.e("Error", e.message!!)
            }
        }
    }

    fun updateData(givenName: String, familyName: String, age: String, id: Int){
        viewModelScope.launch {
            try {
                userRepository.updateData(givenName, familyName, age, id)
                listener.onUpdate()
            } catch (e: Exception){
                Log.e("Error", e.message!!)
            }
        }
    }
}