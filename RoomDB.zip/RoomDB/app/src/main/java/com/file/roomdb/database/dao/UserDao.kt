package com.file.roomdb.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.file.roomdb.AppConstants
import com.file.roomdb.database.entity.User

@Dao
interface UserDao {

    @Query("SELECT * FROM ${AppConstants.UserTable}")
    suspend fun getAllData(): MutableList<User>

    @Insert
    suspend fun insertData(user: User)

    @Query("DELETE FROM ${AppConstants.UserTable} WHERE id = :id")
    suspend fun deleteData(id: Int)

    @Query("SELECT * FROM ${AppConstants.UserTable} WHERE id = :id")
    suspend fun getData(id: Int): User

    @Query("UPDATE ${AppConstants.UserTable} SET given_name = :givenName, family_name = :familyName, age = :age WHERE id = :id")
    suspend fun updateData(givenName: String, familyName: String, age: String, id: Int)
}