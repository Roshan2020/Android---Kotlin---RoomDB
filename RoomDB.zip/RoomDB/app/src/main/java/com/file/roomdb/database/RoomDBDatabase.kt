package com.file.roomdb.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.file.roomdb.AppConstants
import com.file.roomdb.database.dao.UserDao
import com.file.roomdb.database.entity.User

@Database(entities = [User::class], version = 1)
abstract class RoomDBDatabase: RoomDatabase() {
    abstract fun UserDao(): UserDao
}

object DatabaseBuilder{
    var INSTANCE: RoomDBDatabase? = null

    fun getInstance(context: Context): RoomDBDatabase {
        if(INSTANCE == null){
            INSTANCE = build(context)
        }
        return INSTANCE!!
    }

    fun build(context: Context) = Room.databaseBuilder(context, RoomDBDatabase::class.java, AppConstants.Database).build()
}