package com.file.roomdb.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.file.roomdb.AppConstants
import com.file.roomdb.R
import com.file.roomdb.database.DatabaseBuilder
import com.file.roomdb.database.RoomDBDatabase
import com.file.roomdb.database.entity.User
import com.file.roomdb.databinding.ActivityUpdateUserBinding
import com.file.roomdb.listener.UserListener
import com.file.roomdb.repository.UserRepository
import com.file.roomdb.viewmodel.UserViewModel

class UpdateUserActivity : AppCompatActivity(), UserListener {
    var binding: ActivityUpdateUserBinding? = null
    var database: RoomDBDatabase? = null
    var viewModel: UserViewModel? = null
    var user: User? = null
    var id = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateUserBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        database = DatabaseBuilder.getInstance(this)
        viewModel = UserViewModel(this, UserRepository(database!!.UserDao()))
        if(intent.hasExtra(AppConstants.UserID)) {
            id = intent.getIntExtra(AppConstants.UserID, 0)
            viewModel!!.getData(id)
        }

        binding!!.btSubmit.setOnClickListener{
            viewModel!!.updateData(
                binding!!.etGivenName.editableText.toString(), binding!!.etFamilyName.editableText.toString(), binding!!.etAge.editableText.toString(), id
            )
        }
    }

    override fun onInsert() {

    }

    override fun onGetData(user: MutableList<User>) {

    }

    override fun onUpdate(position: Int) {

    }

    override fun onUpdate() {
        finish()
    }

    override fun onDelete(id: Int) {

    }

    override fun onGetUser(user: User) {
        this.user = user
        binding!!.etGivenName.setText(user.givenName)
        binding!!.etFamilyName.setText(user.familyName)
        binding!!.etAge.setText(user.age)
    }
}