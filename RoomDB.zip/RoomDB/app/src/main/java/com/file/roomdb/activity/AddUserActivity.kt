package com.file.roomdb.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.file.roomdb.R
import com.file.roomdb.adapter.UserAdapter
import com.file.roomdb.database.DatabaseBuilder
import com.file.roomdb.database.RoomDBDatabase
import com.file.roomdb.database.entity.User
import com.file.roomdb.databinding.ActivityAddUserBinding
import com.file.roomdb.listener.UserListener
import com.file.roomdb.repository.UserRepository
import com.file.roomdb.viewmodel.UserViewModel

class AddUserActivity : AppCompatActivity(), UserListener{
    var binding: ActivityAddUserBinding? = null
    var userViewModel: UserViewModel? = null
    var database: RoomDBDatabase? =  null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddUserBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        database = DatabaseBuilder.getInstance(this)
        userViewModel = UserViewModel(this, UserRepository(database!!.UserDao()))

        binding!!.btSubmit.setOnClickListener{
            if(binding!!.etGivenName.text.isEmpty()){
                Toast.makeText(this@AddUserActivity, "Error in the Given Name!", Toast.LENGTH_SHORT).show()
            } else if (binding!!.etFamilyName.text.isEmpty()){
                Toast.makeText(this@AddUserActivity, "Error in the Family Name!", Toast.LENGTH_SHORT).show()
            } else if (binding!!.etAge.text.isEmpty()){
                Toast.makeText(this@AddUserActivity, "Error in the Age!", Toast.LENGTH_SHORT).show()
            } else {
                addUser()
            }
        }
    }

    fun addUser(){
        var user: User = User(binding!!.etGivenName.editableText.toString(),binding!!.etFamilyName.editableText.toString(), binding!!.etAge.editableText.toString())
        userViewModel!!.insertData(user)
    }

    override fun onInsert() {
        finish()
    }

    override fun onGetData(user: MutableList<User>) {

    }

    override fun onUpdate(position: Int) {

    }

    override fun onUpdate() {

    }

    override fun onDelete(position: Int) {

    }

    override fun onGetUser(user: User) {

    }
}