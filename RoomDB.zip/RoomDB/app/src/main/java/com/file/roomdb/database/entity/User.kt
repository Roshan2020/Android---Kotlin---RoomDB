package com.file.roomdb.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.file.roomdb.AppConstants

@Entity(tableName = AppConstants.UserTable)
data class User(
    @ColumnInfo(name = "given_name") val givenName: String?,
    @ColumnInfo(name = "family_name") val familyName: String?,
    @ColumnInfo(name = "age") val age: String?
){
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int? = null
}
